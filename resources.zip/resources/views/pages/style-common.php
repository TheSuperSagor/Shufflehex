<!-- Bootstrap CSS CDN -->
<link rel="stylesheet" href="<?=$root?>css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Our Custom CSS -->
<link rel="stylesheet/less" href="<?=$root?>less/style.less">
<link rel="stylesheet/less" href="<?=$root?>less/sidebar.less">

<!--<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/2.7.2/less.min.js"></script>-->
