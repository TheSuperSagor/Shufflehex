<!-- jQuery CDN -->
<!--         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>-->
<script src="<?=$root?>js/less.min.js"></script>
<script src="<?=$root?>js/jquery-3.2.1.min.js"></script>
<!-- Bootstrap Js CDN -->
<script src="<?=$root?>js/bootstrap.min.js"></script>
<!-- jQuery Nicescroll CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.6.8-fix/jquery.nicescroll.min.js"></script>
<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<script src="<?=$root?>js/home.js"></script>