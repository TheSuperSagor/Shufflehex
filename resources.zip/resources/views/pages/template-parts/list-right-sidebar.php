<div id="list-right-sidebar">
    <div class="sidebar-add-image">
        <img src="http://via.placeholder.com/350x250">
    </div>
</div> 