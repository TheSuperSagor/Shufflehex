<?php
include "top-saved-bar.php";
?>
<div id="" class="row">
    <div class="container-fluid">
        <h3>Folder</h3>
    </div>
    <div class="container-fluid">
        <div class="folders">
            <table class="table table-folder table-responsive">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Modified</th>
                    <th class="text-right"><span class="btn"><i class="fa fa-th-list"></i></span></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        <span><i class="fa fa-folder"></i></span>&nbsp;
                        <span>Folder 1</span>
                    </td>
                    <td>01-01-2017</td>
                    <td  class="text-right"><a class="btn btn-danger btn-option"><i class="fa fa-ellipsis-h"></i></a></td>
                </tr>
                <tr>
                    <td>
                        <span><i class="fa fa-folder"></i></span>&nbsp;
                        <span>Folder 1</span>
                    </td>
                    <td>01-01-2017</td>
                    <td class="text-right"><a class="btn btn-default btn-option"><i class="fa fa-ellipsis-h"></i></a></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>
