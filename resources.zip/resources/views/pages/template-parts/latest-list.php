<div id="latest-list">
    <div class="row">
        <div class="col-md-1"><span></span></div>
        <div class="col-md-11 plr-1"><h3>Latest Stories</h3></div>
    </div>
    
    
    <div class="stories">
        <div class="story-item">
            <div class="row">
                <div class="col-md-1 col-sm-1 plr-1" style="height: 100%">
                    <div class="like-thumb text-center">
                        <a href="#"><img class="thumbs-up" src="<?=$root?>/icons/thumb.svg"></a><br>
                        <span class="vote-counter text-center">1212</span><br>
                        <a href="#"><img class="thumbs-down" src="<?=$root?>/icons/thumb.svg"></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-4 plr-1">
                    <div class="story-img">
                        <a href="#"><img class="" src="http://itnextdigital.com/wp-content/uploads/2015/10/FIFA-16-Gallery-Image-01-250x140.jpg"></a>
                    </div>
                </div>
                <div class="col-md-8 col-sm-7 plr-1">
                    <p class="story-domain">domain.com</p>
                    <h4 class="story-title">15 Natural Swimming Pools that No one Believes are Real</h4>
                    <p><small>Sumitted at <strong><span class="postTime">12.00 pm</span></strong> by <strong><span>Username</span></strong> in <strong>Category</strong></small></p>
                    <div class="list-social-share">
                        <a href="#" class="icon-share-circle"><i class="fa fa-facebook"></i></a>
                        <a href="#" class="icon-share-circle"><i class="fa fa-twitter"></i></a>
                        <a href="#" class="icon-share-circle"><i class="fa fa-google-plus"></i></a>
                        <a href="#" class="icon-share-circle"><i class="fa fa-bookmark"></i></a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
