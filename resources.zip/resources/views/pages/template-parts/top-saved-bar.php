<div id="top-saved-bar" class="row">
    <ul class="nav navbar-nav">
        <li><a class="btn" data-toggle="modal" data-target="#saveNewListModal"><i class="fa fa-plus-square"></i> Save New Story</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right" style="margin-right: 10px">
        <li><a class="btn" data-toggle="modal" data-target="#createNewFolderModal"><i class="fa fa-folder"></i> Create New Folder</a></li>
    </ul>
</div>