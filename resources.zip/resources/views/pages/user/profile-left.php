<div class="list-group">
    <a href="posts.php" class="list-group-item">My Posts</a>
    <a href="saved.php" class="list-group-item">Saved Post</a>
    <a href="comments.php" class="list-group-item">Comments</a>
    <a href="notifications.php" class="list-group-item">Notification</a>
    <a href="profile.php" class="list-group-item">Profile Info</a>
</div>