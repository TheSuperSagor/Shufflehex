<div id="profile-sidebar-nav">
    <div class="panel panel-default">
        <div class="panel-heading">
            <span>Profile</span>
        </div>
        <ul class="list-unstyled">
            <li><a href="profile.php">Home</a></li>
            <li><a href="myposts.php">Posts</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="change-password.php">Change Passoword</a></li>
            <li><a href="social-info.php">Social Info</a></li>
            <li><a href="">Logout</a></li>
        </ul>
    </div>
</div>