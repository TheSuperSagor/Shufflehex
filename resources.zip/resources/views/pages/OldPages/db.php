<?php
$conn = new mysqli("localhost","root","","shuffling") or die();