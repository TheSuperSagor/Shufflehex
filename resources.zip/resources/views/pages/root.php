<?php
$_SERVER['DOCUMENT_ROOT'] = "http://".$_SERVER['SERVER_ADDR'].":".$_SERVER['SERVER_PORT']."/shufflestatic/";
$root = $_SERVER['DOCUMENT_ROOT'];


?>