<div id="right-sidebar" class="col-md-3">
    <div id="list-right-sidebar">
        <div class="sidebar-add-image">
            <img src="http://via.placeholder.com/350x250">
        </div>
    </div>
</div>