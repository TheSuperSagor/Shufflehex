<nav id="sidebar">
    <div id="dismiss">
        <i class="glyphicon glyphicon-arrow-left"></i>
    </div>
    <div class="sidebar-mobile-panel">
        <div class="sidebar-link-list">
            <ul class="list-unstyled">
                <li><a href="#">Latest Stories</a></li>
                <li><a href="#">Top Stories</a></li>
                <li><a href="#">Popular Stories</a></li>
                <li><a href="#">Trending Stories</a></li>
            </ul>
        </div>
        <div class="sidebar-link-list">
            <ul class="list-unstyled">
                <li><a href="#">All</a></li>
                <li><a href="#">Web</a></li>
                <li><a href="#">Images</a></li>
                <li><a href="#">Videos</a></li>
                <li><a href="#">Articles</a></li>
                <li><a href="#">Lists</a></li>
                <li><a href="#">Polls</a></li>
            </ul>
        </div>
        <div class="sidebar-link-list">
            <ul class="list-unstyled">
                <li><a href="#">My Profile</a></li>
                <li><a href="#">Saved Stories</a></li>
                <li><a href="#">Add Story</a></li>
                <li><a href="#">Settings</a></li>
                <li><a href="#">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>