<meta charset="UTF-8">

<meta name="viewport" content="width=device-width,initial-scale=1.0">

<link rel="stylesheet" type="text/css" href="{{ asset('shufflehex/css/bootstrap.min.css') }}">

<link rel="stylesheet" type="text/css" href="{{ asset('shufflehex/css/animate.css') }}">

<link rel="stylesheet" type="text/css" href="{{ asset('shufflehex/font-awesome/css/font-awesome.min.css') }}">

<link rel="stylesheet/less" type="text/css" href="{{ asset('shufflehex/style.less') }}">


<!-- Latest compiled and minified CSS -->

<link rel="stylesheet" href="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css') }}">











<script type="text/javascript" src="{{ asset('shufflehex/js/jquery.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('shufflehex/js/bootstrap.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('shufflehex/js/less.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('shufflehex/js/main.js') }}"></script>




{{--<script type="text/javascript" src="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/jquery-dateFormat/1.0/jquery.dateFormat.min.js') }}"></script>--}}

<script type="text/javascript" src="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.19.1/moment.min.js') }}"></script>



<!-- Latest compiled and minified JavaScript -->

<script src="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js') }}"></script>

