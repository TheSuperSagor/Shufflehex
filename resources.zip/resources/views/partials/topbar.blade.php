<div id="topbar">
    <nav class="navbar navbar-static-top text-center">
        <div class="container">
            <a class="navbar-brand" href="{{ route('login') }}"><img src="{{ asset('shufflehex/images/resized_logo.png') }}"></a>
            <div class="pull-right">
                <button type="button" id="menu-icon" class="" onclick="sidebar_open()">
                    <span class="fa fa-bars"></span>
                </button>
            </div>
        </div>
    </nav>
</div>